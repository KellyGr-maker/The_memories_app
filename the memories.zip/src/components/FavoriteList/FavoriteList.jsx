import {
  Paper,
  Grid,
  Button,
  Typography,
} from "@mui/material";

export default function FavoriteList({
  products,
  onAddProduct,
}) {
  return (
    <Paper
      elevation={3}
      sx={{
        p: 2,
        borderRadius: 3,
        height: 420,
        overflowY: "auto",
      }}
    >
      <Typography
        variant="h6"
        fontWeight="bold"
        mb={2}
      >
        ⭐ Favorieten
      </Typography>

      <Grid container spacing={1}>
        {products.map((product) => (
          <Grid size={12} key={product.id}>
            <Button
              fullWidth
              variant="contained"
              onClick={() => onAddProduct(product)}
              sx={{
                justifyContent: "space-between",
                textTransform: "none",
                height: 56,
                borderRadius: 2,
                fontWeight: "bold",
              }}
            >
              <span>{product.name}</span>
              <span>€ {product.price.toFixed(2)}</span>
            </Button>
          </Grid>
        ))}
      </Grid>
    </Paper>
  );
}